#!/bin/sh
SCRIPT_FILE=$0
TOPDIR=${SCRIPT_FILE%/*}
cd $TOPDIR
TOPDIR=`pwd`

CALTOOL=$TOPDIR/cal

cd /system/workdir
. ./evn.sh

cd $TOPDIR

LED_OPERATE=$1
LED_INDEX=$2
LED_DELAY=$3

set_gpio_input()
{
	local index=$1
	local index_dec=1
	local gpiomode
	local t
	
	index_dec=`$CALTOOL l 1 $index`
	gpiomode=`reg p 600`
	
	let "index_dec=4294967296-$index_dec"
	t=`$CALTOOL '&' $index_dec $gpiomode`

	reg w 600 $t
}

set_gpio_output()
{
	local index=$1
	local index_dec=`$CALTOOL l 1 $index`
	local gpiomode=`reg p 600`
	
	t=`$CALTOOL '|' $index_dec $gpiomode`
	echo $t
	reg w 600 $t
}

get_gpio_level()
{
	local index=$1
	local gpiolevel=`reg p 620`
	local t=`$CALTOOL d $gpiolevel`
	local level=`$CALTOOL r $gpiolevel $index`
	level=`expr $level % 2`
	$CALTOOL 'd' $level

	return $level
}

set_gpio_level()
{
	local index=$1
	local level=$2
	local gpiolevel=`reg p 620`
	local index_dec=`$CALTOOL l 1 $index`
	
	if [ $level -eq 0 ]; then
		let "index_dec=4294967296-$index_dec"
		t=`$CALTOOL '&' $index_dec $gpiolevel`
	else
		t=`$CALTOOL '|' $index_dec $gpiolevel`
	fi

	reg w 620 $t
}

main()
{
	reg s 0
	if [ "$LED_OPERATE" == "level" ]; then
		set_gpio_output $LED_INDEX
		set_gpio_level $LED_INDEX $LED_DELAY
	else
		while :
		do
			set_gpio_output $LED_INDEX
			set_gpio_level $LED_INDEX 0
			$CALTOOL 's' $LED_DELAY
			set_gpio_output $LED_INDEX
			set_gpio_level $LED_INDEX 1
			$CALTOOL 's' $LED_DELAY
		done
	fi
}

main