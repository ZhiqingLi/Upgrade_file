#!/bin/sh

SCRIPT_FILE=$0
TOPDIR=${SCRIPT_FILE%/*}

cd $TOPDIR
TOPDIR=`pwd`

cd /system/workdir
. ./evn.sh
cd $TOPDIR

LED_SHELL_NAME="led.sh"
LED_SHELL=$TOPDIR/$LED_SHELL_NAME
CALTOOL=$TOPDIR/cal

SFSFILE=evk-nebula-generic-6.120.0.13-16m.sfs
IFLASHFILE=iflash.bin
LED1=16
LED2=15

NEW_VERSION="6.120.0.13"

set_gpio_input()
{
	local index=$1
	local index_dec=1
	local gpiomode
	local t
	
	index_dec=`$CALTOOL l 1 $index`
	gpiomode=`reg p 600`
	
	let "index_dec=4294967296-$index_dec"
	t=`$CALTOOL '&' $index_dec $gpiomode`

	reg w 600 $t
}

set_gpio_output()
{
	local index=$1
	local index_dec=`$CALTOOL l 1 $index`
	local gpiomode=`reg p 600`
	
	t=`$CALTOOL '|' $index_dec $gpiomode`
	echo $t
	reg w 600 $t
}

get_gpio_level()
{
	local index=$1
	local gpiolevel=`reg p 620`
	local t=`$CALTOOL d $gpiolevel`
	local level=`$CALTOOL r $gpiolevel $index`
	level=`expr $level % 2`
	$CALTOOL 'd' $level

	return $level
}

set_gpio_level()
{
	local index=$1
	local level=$2
	local gpiolevel=`reg p 620`
	local index_dec=`$CALTOOL l 1 $index`
	
	if [ $level -eq 0 ]; then
		let "index_dec=4294967296-$index_dec"
		t=`$CALTOOL '&' $index_dec $gpiolevel`
	else
		t=`$CALTOOL '|' $index_dec $gpiolevel`
	fi

	reg w 620 $t
}

get_key()
{
	local level

	while :
	do
		set_gpio_input 18
		level=$(get_gpio_level 18)
		
		if [ $level -eq 0 ]; then
			break
		fi
	done
}

show_success()
{
	echo "Upgrade Success, OKAY"
	killall $LED_SHELL_NAME
	$LED_SHELL level $LED1 1
}

show_error()
{
	echo "Upgrade Fail"
	killall $LED_SHELL_NAME
	$LED_SHELL blink $LED1 100 &
}

show_burning()
{
	killall $LED_SHELL_NAME
	$LED_SHELL blink $LED1 700 &
}

show_led_off()
{
	killall $LED_SHELL_NAME
	$LED_SHELL level $LED1 0
}

reset_dsp()
{
	set_gpio_output 14
	set_gpio_level 14 0
	sleep 1
	set_gpio_level 14 1
}

start_test()
{
	show_led_off
	
	while :
	do
		get_key
		show_led_off
		sleep 1

		show_burning
		/system/workdir/bin/cxdish -r 148 -D /dev/i2cM0 -W 60 flash $TOPDIR/$SFSFILE $TOPDIR/$IFLASHFILE
		
		if [ $? -ne 0 ]; then
			show_error
			continue
		fi
		
		reset_dsp
		
		sleep 3
		cxdish fw-version
		OLD_VERSION=`cxdish fw-version`
		echo "version is $OLD_VERSION on device"
		if [ "$OLD_VERSION" == "$NEW_VERSION" ]; then
			show_success
		else
			show_error
		fi
	done
}

main()
{
	reg s 0
	start_test
	echo "Finish"
}

main