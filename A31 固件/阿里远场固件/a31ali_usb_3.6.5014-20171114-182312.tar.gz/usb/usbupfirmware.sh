#!/bin/sh
export LD_LIBRARY_PATH=/system/workdir/lib:/lib/:$LD_LIBRARY_PATH
TOP=`/media/sd*/busybox dirname $0`
cd $TOP
TOP=`pwd`
echo 0 > /proc/sys/kernel/printk
killall mdevnotify
GPIOTOOL=./gpiotool_MT7628

MD5FILE=md5.txt

UPDATE_OK=1
UPDATE_FAIL=0
result=$UPDATE_FAIL
images_broken=0

DIFF="./busybox diff"
CUT="./busybox cut"
WC="./busybox wc"
MD5SUM="./busybox md5sum"
DD="./busybox dd"
CAT="./busybox cat"
GREP="./busybox grep"
USLEEP="./busybox usleep"
XARGS="./busybox xargs"
PRINTF="./busybox printf"

UBOOT=`$CAT $MD5FILE  | $GREP "uboot"  | $CUT -d' ' -f3`
BACKUP=`$CAT $MD5FILE | $GREP "backup" | $CUT -d' ' -f3`
KERNEL=`$CAT $MD5FILE | $GREP "uImage" | $CUT -d' ' -f3`
USER2=`$CAT $MD5FILE | $GREP "user2_jffs2" | $CUT -d' ' -f3`
uboot_file_exists=0
backup_file_exists=0
kernel_file_exists=0
user2_file_exists=0

## SDA(1) SCL(2) DCD_N(12) RIN(14)
## RED LED (DCD_N)
LED1=14
# GPIO12 connect to GPIO10 on Test board
LED1A=0

## Blue LED ( RIN)
LED2=16
# GPIO14 connect to GPIO40 on Test board
LED2A=18



# LED1 OFF, LED2 ON
show_status_burning()
{
	echo "burning..."
	pkill gpiotool
	$GPIOTOOL level 0 $LED1 $LED1A
	$GPIOTOOL level 1 $LED2
	$GPIOTOOL level 1 $LED2A
}

# LED1 ON, LED2 Blink slowly
show_status_update_ok()
{
	echo "update ok..."
	pkill gpiotool
	$GPIOTOOL level 1 $LED1 $LED1A
	while [ 1 ]; do
		$GPIOTOOL level 1 $LED2
		$GPIOTOOL level 1 $LED2A
		$USLEEP 1000000
		$GPIOTOOL level 0 $LED2
		$GPIOTOOL level 0 $LED2A
		$USLEEP 1000000
	done
}

# LED1 blink fast, LED2 blink fast
show_status_update_fail()
{
	echo "update fail"
	pkill gpiotool
	while [ 1 ]; do
		$GPIOTOOL level 1 $LED1 $LED1A
		$GPIOTOOL level 1 $LED2
		$GPIOTOOL level 1 $LED2A
		$USLEEP 100000
		$GPIOTOOL level 0 $LED1 $LED1A
		$GPIOTOOL level 0 $LED2
		$GPIOTOOL level 0 $LED2A
		$USLEEP 100000
	done
}

## set i2c sda/scl to gpio mode
set_i2c_to_gpio_mode()
{
	reg s 0
	gpiomode=`reg p 60`
	t=`printf "%d" $gpiomode`
	let "t=$t|1"
	t=`printf "%x" $t`
	t="0x$t"
	echo "gpio mode from $gpiomode to $t"
	reg w 60 $t
}

## set uartf to gpio mode
set_uartf_to_gpio_mode()
{
	reg s 0
	gpiomode=`reg p 60`
	t=`printf "%d" $gpiomode`
	let "t=$t|28"
	t=`printf "%x" $t`
	t="0x$t"
	echo "gpio mode from $gpiomode to $t"
	reg w 60 $t
}

## set jtag to gpio mode (gpio17-21)
set_jtag_to_gpio_mode()
{
	reg s 0
	gpiomode=`reg p 60`
	t=`printf "%d" $gpiomode`
	let "t=$t|65536"
	t=`printf "%x" $t`
	t="0x$t"
	echo "gpio mode from $gpiomode to $t"
	reg w 60 $t
}


init_gpio()
{
	#set_i2c_to_gpio_mode
	set_uartf_to_gpio_mode
	set_jtag_to_gpio_mode
}

main()
{
#free memory
pkill rootApp
echo 3 > /proc/sys/vm/drop_caches
telnetd &

#check md5
rm -f /tmp/images.md5
rm -f /tmp/md5.txt
if [ "$UBOOT" != "" ] && [ -f $UBOOT ]; then
$MD5SUM $UBOOT > /tmp/images.md5
$CAT $MD5FILE  | $GREP "uboot" > /tmp/md5.txt
uboot_file_exists=1
fi

if [ "$BACKUP" != "" ] && [ -f $BACKUP ]; then
$MD5SUM $BACKUP >> /tmp/images.md5
$CAT $MD5FILE  | $GREP "backup" >> /tmp/md5.txt
backup_file_exists=1
fi

if [ "$KERNEL" != "" ] && [ -f $KERNEL ]; then
$MD5SUM $KERNEL >> /tmp/images.md5
$CAT $MD5FILE  | $GREP "uImage" >> /tmp/md5.txt
kernel_file_exists=1
fi

if [ "$USER2" != "" ] && [ -f $USER2 ]; then
$MD5SUM $USER2 >> /tmp/images.md5
$CAT $MD5FILE  | $GREP "user2_jffs2" >> /tmp/md5.txt
user2_file_exists=1
fi

$DIFF /tmp/images.md5 /tmp/md5.txt
images_broken=$?

${DIFF} ${TOP}/MVver /system/workdir/MVver
version_diff=$?


# set restore flag no matter what happens
#ralink_init clear 2860
nvram_set 2860 WebInit 0
rm -rf /mnt/vendor/download
rm -rf /mnt/vendor/downloadorg
rm -rf /mnt/keymap.xml
rm -rf /mnt/totalqueue.xml
rm -rf /mnt/.queue.init
rm -rf /mnt/defualt_ssid_mcu

need_to_update=0

if [ $images_broken -eq 1 ]; then
	echo "images are broken, need to check!"
	result=$UPDATE_FAIL
	cp /tmp/images.md5 ${MD5FILE}.err
	need_to_update=0
elif [ $version_diff -eq 0 ]; then
	echo "nversion is same, check more"
	rm -f ${MD5FILE}.err

	# compare flash partitions to our images
	#1) get size of each image
	if [ $uboot_file_exists -eq 1 ]; then
	UBOOT_SIZE=`$WC -c $UBOOT | $XARGS $PRINTF "%d %s" | $CUT -d' ' -f1`
	UBOOT_SIZE=`expr $UBOOT_SIZE`
	fi

	if [ $backup_file_exists -eq 1 ]; then
	BACKUP_SIZE=`$WC -c $BACKUP | $XARGS $PRINTF "%d %s" | $CUT -d' ' -f1`
	BACKUP_SIZE=`expr $BACKUP_SIZE`
	fi

	if [ $kernel_file_exists -eq 1 ]; then
	KERNEL_SIZE=`$WC -c $KERNEL | $XARGS $PRINTF "%d %s" | $CUT -d' ' -f1`
	KERNEL_SIZE=`expr $KERNEL_SIZE`
	fi

	if [ $user2_file_exists -eq 1 ]; then
	USER2_SIZE=`$WC -c $USER2 | $XARGS $PRINTF "%d %s" | $CUT -d' ' -f1`
	USER2_SIZE=`expr $USER2_SIZE`
	fi
echo "===========Compare before Write==========="
cat /proc/uptime
echo "==========================="

	need_to_update=0
	#2) compare kernel
	if [ $kernel_file_exists -eq 1 ] && [ $need_to_update -eq 0 ]; then
		$DD if=/dev/mtdblock7 of=/tmp/image.tmp bs=$KERNEL_SIZE count=1
		md5_udisk=`$CAT $MD5FILE | $GREP "$KERNEL" | $CUT -d' ' -f1`
		md5_flash=`$MD5SUM /tmp/image.tmp | $CUT -d' ' -f1`
		if [ "$md5_flash" != "$md5_udisk" ]; then
			echo "Kernel is different"
			need_to_update=1
		else
			echo "Kernel is the same"
			kernel_file_exists=0
		fi
	fi

	#3) compare bootloader
	if [ $uboot_file_exists -eq 1 ] && [ $need_to_update -eq 0 ]; then
		$DD if=/dev/mtdblock1 of=/tmp/image.tmp bs=$UBOOT_SIZE count=1
		md5_udisk=`$CAT $MD5FILE | $GREP "$UBOOT" | $CUT -d' ' -f1`
		md5_flash=`$MD5SUM /tmp/image.tmp | $CUT -d' ' -f1`
		if [ "$md5_flash" != "$md5_udisk" ]; then
			echo "Uboot is different"
			need_to_update=1
		else
			echo "Uboot is the same"
			uboot_file_exists=0
		fi
	fi

	#4) compare backup
	if [ $backup_file_exists -eq 1 ] && [ $need_to_update -eq 0 ]; then
		$DD if=/dev/mtdblock4 of=/tmp/image.tmp bs=$BACKUP_SIZE count=1
		md5_udisk=`$CAT $MD5FILE | $GREP "$BACKUP" | $CUT -d' ' -f1`
		md5_flash=`$MD5SUM /tmp/image.tmp | $CUT -d' ' -f1`
		if [ "$md5_flash" != "$md5_udisk" ]; then
			echo "Backup is different"
			need_to_update=1
		else
			echo "Backup is the same"
			backup_file_exists=0
		fi
	fi

	#5) compare user2
	if [ $user2_file_exists -eq 1 ] && [ $need_to_update -eq 0 ]; then
		$DD if=/dev/mtdblock9 of=/tmp/image.tmp bs=$USER2_SIZE count=1
		md5_udisk=`$CAT $MD5FILE | $GREP "$USER2" | $CUT -d' ' -f1`
		md5_flash=`$MD5SUM /tmp/image.tmp | $CUT -d' ' -f1`
		if [ "$md5_flash" != "$md5_udisk" ]; then
			echo "User2 is different"
			need_to_update=1
			umount -l /dev/mtdblock9
		else
			echo "User2 is the same"
			user2_file_exists=0
		fi
	fi

echo "===========Compare before Write Done==========="
cat /proc/uptime
echo "==========================="

	if [ $need_to_update -eq 0 ]; then
		result=$UPDATE_OK
	fi
else
	need_to_update=1
fi

#################################### update ###########################
if [ $need_to_update -ne 0 ]; then
echo "===========Start to update==========="
cat /proc/uptime
echo "==========================="
	rm -f /tmp/image.tmp
	show_status_burning
	ret=0
	if [ $ret -eq 0 ] && [ $backup_file_exists -eq 1 ]; then
		cp $BACKUP /dev/mtdblock4
		ret=$?
	fi

	if [ $ret -eq 0 ] && [ $uboot_file_exists -eq 1 ]; then
		cp $UBOOT /dev/mtdblock1
		ret=$?
	fi

	if [ $ret -eq 0 ] && [ $user2_file_exists -eq 1 ]; then
		mtd_write erase user2
		cp $USER2 /dev/mtdblock9
		ret=$?
	fi

	if [ $ret -eq 0 ] && [ $kernel_file_exists -eq 1 ]; then
		cp $KERNEL /dev/mtdblock7
		ret=$?
	fi
	sync
	if [ $ret -eq 0 ]; then
echo "===========Compare after Write==========="
cat /proc/uptime
echo "==========================="

		#1) get size of each image
		if [ $uboot_file_exists -eq 1 ]; then
		UBOOT_SIZE=`$WC -c $UBOOT | $XARGS $PRINTF "%d %s" | $CUT -d' ' -f1`
		UBOOT_SIZE=`expr $UBOOT_SIZE`
		fi

		if [ $backup_file_exists -eq 1 ]; then
		BACKUP_SIZE=`$WC -c $BACKUP | $XARGS $PRINTF "%d %s" | $CUT -d' ' -f1`
		BACKUP_SIZE=`expr $BACKUP_SIZE`
		fi

		if [ $kernel_file_exists -eq 1 ]; then
		KERNEL_SIZE=`$WC -c $KERNEL | $XARGS $PRINTF "%d %s" | $CUT -d' ' -f1`
		KERNEL_SIZE=`expr $KERNEL_SIZE`
		fi

		if [ $user2_file_exists -eq 1 ]; then
		USER2_SIZE=`$WC -c $USER2 | $XARGS $PRINTF "%d %s" | $CUT -d' ' -f1`
		USER2_SIZE=`expr $USER2_SIZE`
		fi

		#compare
		need_to_compare=1
		#2) compare kernel
		if [ $kernel_file_exists -eq 1 ] && [ $need_to_compare -eq 1 ]; then
			$DD if=/dev/mtdblock7 of=/tmp/image.tmp bs=$KERNEL_SIZE count=1
			md5_udisk=`$CAT $MD5FILE | $GREP "$KERNEL" | $CUT -d' ' -f1`
			md5_flash=`$MD5SUM /tmp/image.tmp | $CUT -d' ' -f1`
			if [ "$md5_flash" != "$md5_udisk" ]; then
				echo "Kernel is different ($md5_flash != $md5_udisk)"
				need_to_compare=0
			else
				echo "Kernel is the same"
			fi
		fi

		#3) compare bootloader
		if [ $uboot_file_exists -eq 1 ] && [ $need_to_compare -eq 1 ]; then
			$DD if=/dev/mtdblock1 of=/tmp/image.tmp bs=$UBOOT_SIZE count=1
			md5_udisk=`$CAT $MD5FILE | $GREP "$UBOOT" | $CUT -d' ' -f1`
			md5_flash=`$MD5SUM /tmp/image.tmp | $CUT -d' ' -f1`
			if [ "$md5_flash" != "$md5_udisk" ]; then
				echo "Uboot is different ($md5_flash != $md5_udisk)"
				need_to_compare=0
			else
				echo "Uboot is the same"
			fi
		fi

		#4) compare backup
		if [ $backup_file_exists -eq 1 ] && [ $need_to_compare -eq 1 ]; then
			$DD if=/dev/mtdblock4 of=/tmp/image.tmp bs=$BACKUP_SIZE count=1
			md5_udisk=`$CAT $MD5FILE | $GREP "$BACKUP" | $CUT -d' ' -f1`
			md5_flash=`$MD5SUM /tmp/image.tmp | $CUT -d' ' -f1`
			if [ "$md5_flash" != "$md5_udisk" ]; then
				echo "Backup is different ($md5_flash != $md5_udisk)"
				need_to_compare=0
			else
				echo "Backup is the same"
			fi
		fi

		#5) compare user2
		if [ $user2_file_exists -eq 1 ] && [ $need_to_compare -eq 1 ]; then
			$DD if=/dev/mtdblock9 of=/tmp/image.tmp bs=$USER2_SIZE count=1
			md5_udisk=`$CAT $MD5FILE | $GREP "$USER2" | $CUT -d' ' -f1`
			md5_flash=`$MD5SUM /tmp/image.tmp | $CUT -d' ' -f1`
			if [ "$md5_flash" != "$md5_udisk" ]; then
				echo "User2 is different ($md5_flash != $md5_udisk)"
				need_to_compare=0
			else
				echo "User2 is the same"
			fi
		fi

		if [ $need_to_compare -eq 1 ]; then
			result=$UPDATE_OK
		else
			result=$UPDATE_FAIL
		fi

	else
		result=$UPDATE_FAIL
	fi
fi

echo "===========DONE==========="
cat /proc/uptime
echo "==========================="

resultstr=""
if [ $result -eq $UPDATE_OK ]; then
	show_status_update_ok
	resultstr="ok"
else
	show_status_update_fail
	resultstr="fail"
fi

}


init_gpio
main

while [ 1 ]; do
	echo "sleep forever, result: $resultstr"
	sleep 10
done



